package main;

import view.LoginFrame;

public class SupSysApp {
	public static void main(String [] args) {
		LoginFrame loginFrame = new LoginFrame();
		
	} 
}
