package model;

import java.sql.ResultSet;
import java.sql.Statement;

public class SystemDAO {
	public SystemDAO(){
		
	}
	/**
	 * 
	 * @param key,String ��Ҫ��ѯֵ�Ĳ�����
	 * @return String ��ѯ�Ĳ���ֵ
	 */
	public String getParameter(String key){
		String result=null;
		try {
			
			Statement stmt = DBTool.getStatement(); 
			String sqlStr = "select CONF_VALUE from SYS_CONF " + "where CONF_KEY='" 
						+ key + "'";
			ResultSet rs = stmt.executeQuery(sqlStr);
			if (rs.next()) 
				result = rs.getString(1);
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}
    public boolean updateParameter(String key,String value){
	    boolean result = false;
	try {
		
		Statement stmt = DBTool.getStatement(); 
		String sqlStr = "update SYS_CONF set"+" CONF_VALUE=' " +value+ "'where CONF_KEY='" 
					+ key + "'";
		if( stmt.executeUpdate(sqlStr)>0);
           result=true;
	}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return result;
}
}
