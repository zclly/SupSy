package model;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class UsersTableModel extends AbstractTableModel {
	ArrayList<ArrayList<String>> users;
	String[] columnName={"�û���","����","��ʵ����"};
	public UsersTableModel(){
		UserDAO userDAO=new UserDAO();
		users=userDAO.userList();
	}
	public String getColumnName(int column){
		return columnName[column];
	}

	@Override
	public int getColumnCount() {
		if(users.size()==0){
			return 0;
		}
		return users.get(0).size();
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return users.size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		// TODO Auto-generated method stub
		return users.get(row).get(column);
	}

}
