package view;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JCheckBoxMenuItem;

public class MainFrame extends JFrame {
	private String realName;
	public MainFrame(String realName) {
		this.realName=realName;
		setTitle("��ӭ"+realName+"ʹ�ó��й���ϵͳ");
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("ϵͳ");
		menuBar.add(menu);		
		JMenuItem menuItem = new JMenuItem("\u8BBE\u7F6E");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ParaDialog(MainFrame.this,true);
			}
		});
		
		JMenuItem menuItem_2 = new JMenuItem("\u4F1A\u5458\u6CE8\u518C");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddUserDialog addUserDialog=new AddUserDialog(MainFrame.this,true);
			}
		});
		menu.add(menuItem_2);
		menu.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("\u9000\u51FA");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		
		JMenuItem menuItem_3 = new JMenuItem("\u5546\u54C1\u5217\u8868");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new UserListDialog(MainFrame.this,true);//��ʾUserListDialog
			}
		});
		menu.add(menuItem_3);
		menu.add(menuItem_1);
		
		
		this.setSize(500,400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
	}

}
