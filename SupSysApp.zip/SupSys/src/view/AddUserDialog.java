package view;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;

import model.UserDAO;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class AddUserDialog extends JDialog {
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JFrame jFrame;
	private boolean model;
	public AddUserDialog(JFrame jFrame,boolean model) {
		super(jFrame,model);
		this.jFrame=jFrame;
		this.model=model;
		getContentPane().setLayout(null);
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setBounds(30, 52, 72, 18);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801\uFF1A");
		label_1.setBounds(30, 102, 72, 18);
		getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label_2.setBounds(14, 144, 88, 18);
		getContentPane().add(label_2);
		
		textField = new JTextField();
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				checkName();
			}
		});
		textField.setBounds(107, 49, 143, 24);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u6CE8\u518C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddUser();
			}
		});
		button.setBounds(14, 294, 113, 27);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.setBounds(173, 294, 113, 27);
		getContentPane().add(button_1);
		
		JLabel lblNewLabel = new JLabel("\u771F\u5B9E\u59D3\u540D\uFF1A");
		lblNewLabel.setBounds(14, 185, 88, 18);
		getContentPane().add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(107, 182, 143, 24);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(107, 99, 143, 24);
		getContentPane().add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(107, 141, 143, 24);
		getContentPane().add(passwordField_1);
		
		JLabel label_3 = new JLabel("\u7528\u6237\u540D\u5B57\u7B26\u6570\u57286-20\u4E4B\u95F4");
		label_3.setBounds(264, 52, 184, 18);
		getContentPane().add(label_3);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801\u5B57\u7B26\u6570\u57286-10\u4E4B\u95F4");
		lblNewLabel_1.setBounds(273, 102, 162, 18);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u518D\u6B21\u8F93\u5165\u5BC6\u7801");
		lblNewLabel_2.setBounds(283, 144, 143, 18);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u771F\u540D\u5B57\u7B26\u6570\u57286-20\u4E4B\u95F4");
		lblNewLabel_3.setBounds(273, 188, 162, 18);
		getContentPane().add(lblNewLabel_3);
		this.setSize(500,400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	protected void checkName() {
		// TODO Auto-generated method stub
		String userName=textField.getText().trim();
		UserDAO userDAO=new UserDAO();
		if(userDAO.checkName(userName)!=null){
		JOptionPane.showMessageDialog(this, "���û����Ѿ����ڣ����������룡");
		textField.grabFocus();
		};
	}
	/**
	 * ����ϵͳ�û�
	 */
	protected void AddUser() {
     //��ȡ��������
		String userName=textField.getText().trim();
		String realName=textField_1.getText().trim();
		String password=new String(passwordField.getPassword()).trim();
		String password_1=new String(passwordField.getPassword()).trim();
		//�ǿ���֤
		if("".equals(userName)){
			JOptionPane.showMessageDialog(this, "�������û���");
			return;
		}
		if("".equals(realName)){
			JOptionPane.showMessageDialog(this, "���ٴ������û���");
			return;
		}
		if("".equals(password)){
			JOptionPane.showMessageDialog(this, "����������");
			return;
		}
		if("".equals(password_1)){
			JOptionPane.showMessageDialog(this, "ȷ������");
			return;
		}
		if(!password.equals(password_1)){
			JOptionPane.showMessageDialog(this, "���벻һ�£�����������");
			return;
		}
		//��Ч�Ե���֤
		if(userName.length()>20||userName.length()<6){
			JOptionPane.showMessageDialog(this, "�û����ַ�����6-20֮��");
			return;
		}
		if(password.length()>10||password.length()<6){
			JOptionPane.showMessageDialog(this, "�����ַ�����6-10֮��");
			return;
		}
		if(realName.length()>20||realName.length()<6){
			JOptionPane.showMessageDialog(this, "�����ַ�����6-20֮��");
			return;
		}
     //�����û�
		UserDAO userDAO=new UserDAO();
		try {
			if(userDAO.addUser(userName, realName, password)){
				JOptionPane.showMessageDialog(this, "�����û��ɹ�");
			}
			else {
				JOptionPane.showMessageDialog(this, "�����û�ʧ��");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		JOptionPane.showMessageDialog(this, "�����û�ʧ��");
		}
		
	}
}
