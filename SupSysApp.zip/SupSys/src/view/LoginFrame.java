package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import model.UserDAO;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Toolkit;


public class LoginFrame extends JFrame {
	private JTextField userNameField;
	private JPasswordField passwordField;
	public LoginFrame() {
		getContentPane().setForeground(Color.MAGENTA);
		setBackground(Color.WHITE);
		getContentPane().setBackground(new Color(51, 204, 204));
		getContentPane().setLayout(null);
		JLabel label_1 = new JLabel("密  码:");
		label_1.setBounds(113, 222, 68, 23);
		getContentPane().add(label_1);
		
		userNameField = new JTextField();
		userNameField.setBounds(229, 156, 149, 21);
		getContentPane().add(userNameField);
		userNameField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(229, 222, 149, 21);
		getContentPane().add(passwordField);
		
		JButton button = new JButton("登录");
		button.setBackground(Color.RED);
		button.setForeground(Color.BLUE);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				login();
			}
		});
		button.setBounds(62, 320, 93, 23);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("取消");
		button_1.setBackground(Color.RED);
		button_1.setForeground(Color.BLUE);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			System.exit(0);
			}
		});
		button_1.setBounds(378, 320, 93, 23);
		getContentPane().add(button_1);
		
		JLabel label_2 = new JLabel("龙 哥 超 市");
		label_2.setFont(new Font("华文楷体", Font.PLAIN, 50));
		label_2.setForeground(Color.RED);
		label_2.setBounds(134, 29, 244, 75);
		getContentPane().add(label_2);
		
		JLabel label = new JLabel("员工号：");
		label.setBounds(113, 156, 68, 23);
		getContentPane().add(label);
		setSize(604,466);
		//double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		   //double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		   //tLocation( (int) (width - this.getWidth()) / 2,(int) (height - this.getHeight()) / 2);
		setLocationRelativeTo(null);
		   setVisible(true);
	}
	//ʵ�ֵ�����֤
	protected void login() {
		String userName=userNameField.getText().trim();
		String password=new String(passwordField.getPassword());
		UserDAO userDAO=new UserDAO();
		String realName=userDAO.login(userName, password);
		if(realName!=null){
			MainFrame mainFrame = new MainFrame(realName);
			this.dispose();
		}else{
			System.out.println("输入错误");
		}
	}
}
