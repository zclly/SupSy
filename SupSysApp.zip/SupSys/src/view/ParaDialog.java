package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.SystemDAO;

public class ParaDialog extends JDialog {
	private JTextField textField;
	private JTextField textField_1;
	SystemDAO systemDAO=new SystemDAO();
	private String time;
	private  String fee;
	public ParaDialog(JFrame jFrame,boolean model) {
		super(jFrame,model);
		setTitle("\u53C2\u6570\u8BBE\u7F6E");
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u8BBE\u7F6E\u56FE\u4E66\u501F\u9605\u89C4\u5219\u53C2\u6570");
		label.setBounds(137, 13, 200, 33);
		getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(196, 59, 172, 24);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u786E\u5B9A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nowTime=textField.getText().trim();
				String nowFee=textField_1.getText().trim();
				if(!nowTime.equals(time)){
					systemDAO.updateParameter("TIME", nowTime);
					
				}
				if(!nowTime.equals(fee)){
					systemDAO.updateParameter("FEE", nowFee);
				}
			JOptionPane.showMessageDialog(ParaDialog.this,"��ϲ�㣡���³ɹ�");
			}
		});
		button.setBounds(41, 183, 113, 27);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.setBounds(275, 183, 113, 27);
		getContentPane().add(button_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(196, 114, 172, 24);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_1 = new JLabel("\u501F\u9605\u5929\u6570\uFF1A");
		label_1.setBounds(99, 56, 89, 30);
		getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("\u501F\u9605\u65F6\u95F4:");
		label_2.setBounds(99, 114, 78, 24);
		getContentPane().add(label_2);
		time=systemDAO.getParameter("TIME");
		fee=systemDAO.getParameter("FEE");
		textField.setText(time);
		textField_1.setText(fee);
		this.setSize(500,400);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}
