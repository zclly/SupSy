package view;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;

import model.UserDAO;
import model.UsersTableModel;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.JTable;

import java.awt.BorderLayout;

import javax.swing.JScrollPane;
import javax.swing.JPanel;

public class UserListDialog extends JDialog {
	private JFrame jFrame;
	private boolean model;
	private JTable table;
	private final JPanel panel = new JPanel();
	public UserListDialog(JFrame jFrame,boolean model) {
		super(jFrame,model);
		this.jFrame=jFrame;
		this.model=model;
		this.setSize(500,400);
		this.setLocationRelativeTo(null);
		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		table = new JTable(new UsersTableModel());
		scrollPane.setViewportView(table);
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		JButton btnNewButton = new JButton("ȷ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserListDialog.this.dispose();//�ص�����
			}
		});
		panel.add(btnNewButton);
		this.setVisible(true);
	}
}
