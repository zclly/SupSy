package cn.book.entity;

/**
 * t_book ͼ��� �ֶ�
 * 
 * @author Administrator
 * 
 */

public class Sup {

	private long sup_id; // ��Ʒ���
	private String sup_name; // ��Ʒ��
	private long sup_danjia; // ��Ʒ����
	private String sup_category; // ��Ʒ����
	private String sup_detail; // ��Ʒ����
	private String sup_location; // ��Ʒλ��

	public long getBook_id() {
		return sup_id;
	}

	public void setBook_id(long sup_id) {
		this.sup_id = sup_id;
	}

	public String getBook_name() {
		return sup_name;
	}

	public void setBook_name(String book_name) {
		this.sup_name = sup_name;
	}

	public long getBook_stock() {
		return sup_danjia;
	}

	public void setBook_stock(long sup_danjia) {
		this.sup_danjia = sup_danjia;
	}

	public String getBook_category() {
		return sup_category;
	}

	public void setBook_category(String sup_category) {
		this.sup_category = sup_category;
	}

	public String getBook_detail() {
		return sup_detail;
	}

	public void setBook_detail(String sup_detail) {
		this.sup_detail = sup_detail;
	}

	public String getBook_location() {
		return sup_location;
	}

	public void setBook_location(String sup_location) {
		this.sup_location = sup_location;
	}

	public Sup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sup(long book_id, String book_name, long book_stock,
			String book_category, String book_detail, String book_location) {
		super();
		this.sup_id = sup_id;
		this.sup_name = sup_name;
		this.sup_danjia = sup_danjia;
		this.sup_category = sup_category;
		this.sup_detail = sup_detail;
		this.sup_location = sup_location;
	}

	@Override
	public String toString() {
		return "Sup [sup_id=" + sup_id + ", sup_name=" + sup_name
				+ ", sup_danjia=" + sup_danjia + ", sup_category="
				+ sup_category + ", sup_detail=" + sup_detail
				+ ", sup_location=" + sup_location + "]";
	}

}